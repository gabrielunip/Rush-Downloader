package com.bluerush.downloader

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Navy = Color(0xFF07182E)
private val Blue = Color(0xFF0866D6)
private val Red = Color(0xFFE32936)
private val Orange = Color(0xFFFF7A1A)
private val Panel = Color(0xFF102843)
private val Muted = Color(0xFF9DB2CA)
private val White = Color(0xFFF5F8FF)

data class HistoryItem(val url: String, val title: String, val format: String, val quality: String, val time: Long)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BlueRushApp(this) }
    }
}

@Composable
fun BlueRushApp(activity: MainActivity) {
    val prefs = activity.getSharedPreferences("bluerush", Context.MODE_PRIVATE)
    var url by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    var showOptions by remember { mutableStateOf(false) }
    var selectedFormat by remember { mutableIntStateOf(1) } // swipe: 0 MP3, 1 MP4
    var quality by remember { mutableStateOf("1080p") }
    var notice by remember { mutableStateOf("Cole um link para começar") }
    var history by remember { mutableStateOf(loadHistory(prefs)) }
    var refresh by remember { mutableIntStateOf(0) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, secondary = Red, background = Navy, surface = Panel,
        onPrimary = White, onBackground = White, onSurface = White
    )) {
        Box(Modifier.fillMaxSize().background(Navy)) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Blue, Navy, Red)))
                        .padding(horizontal = 20.dp, vertical = 22.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(46.dp).background(Color.White.copy(alpha=.12f), RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Bolt, null, tint = Orange, modifier = Modifier.size(30.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("BLUE", fontSize = 23.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                        Text("RUSH  •  MEDIA DOWNLOADER", fontSize = 10.sp, color = White.copy(alpha=.8f), letterSpacing = 1.2.sp)
                    }
                    Box(Modifier.background(Red, RoundedCornerShape(30.dp)).padding(horizontal=11.dp, vertical=6.dp)) {
                        Text("SEM ADS", fontSize=10.sp, fontWeight=FontWeight.Bold)
                    }
                }
                Column(Modifier.weight(1f).padding(horizontal=18.dp)) {
                    Spacer(Modifier.height(22.dp))
                    Text("Seu conteúdo.", fontSize=27.sp, fontWeight=FontWeight.Bold)
                    Text("Seu formato. Do seu jeito.", fontSize=16.sp, color=Muted)
                    Spacer(Modifier.height(20.dp))
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(16.dp)) {
                        Text("LINK DO VÍDEO OU ÁUDIO", color=Muted, fontSize=11.sp, fontWeight=FontWeight.Bold, letterSpacing=1.sp)
                        Spacer(Modifier.height(12.dp))
                        Row(verticalAlignment=Alignment.CenterVertically) {
                            Icon(Icons.Default.Link, null, tint=Blue)
                            Spacer(Modifier.width(10.dp))
                            Box(Modifier.weight(1f)) {
                                if (url.isEmpty()) Text("Cole o link aqui...", color=Muted)
                                BasicTextField(value=url, onValueChange={url=it}, modifier=Modifier.fillMaxWidth(), singleLine=true, textStyle=androidx.compose.ui.text.TextStyle(color=White, fontSize=15.sp))
                            }
                            if (url.isNotEmpty()) Icon(Icons.Default.Close, "Limpar", tint=Muted, modifier=Modifier.clickable { url="" })
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                            listOf("YouTube", "Instagram", "TikTok", "Facebook").forEach {
                                Box(Modifier.background(Navy, RoundedCornerShape(30.dp)).padding(horizontal=9.dp, vertical=6.dp)) {
                                    Text(it, fontSize=10.sp, color=Muted)
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Button(
                            onClick = {
                                if (url.isBlank()) notice = "Cole um link primeiro"
                                else { showOptions = true; notice = "Escolha formato e qualidade" }
                            },
                            modifier=Modifier.fillMaxWidth().height(54.dp),
                            colors=ButtonDefaults.buttonColors(containerColor=Red),
                            shape=RoundedCornerShape(15.dp)
                        ) {
                            Icon(Icons.Default.Download, null)
                            Spacer(Modifier.width(8.dp))
                            Text("BAIXAR", fontWeight=FontWeight.Black, letterSpacing=1.5.sp)
                            Spacer(Modifier.width(5.dp))
                            Icon(Icons.Default.ArrowForward, null, modifier=Modifier.size(18.dp))
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, null, tint=Orange, modifier=Modifier.size(17.dp))
                        Spacer(Modifier.width(7.dp))
                        Text(notice, color=Muted, fontSize=12.sp)
                    }
                    Spacer(Modifier.height(24.dp))
                    Row(verticalAlignment=Alignment.CenterVertically) {
                        Text("Sua biblioteca", fontSize=20.sp, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                        Text("${history.size} itens", color=Muted, fontSize=12.sp)
                    }
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(4.dp)) {
                        listOf("Downloads", "Histórico").forEachIndexed { i, label ->
                            Box(Modifier.weight(1f).background(if(tab==i) Blue else Color.Transparent, RoundedCornerShape(11.dp)).clickable { tab=i; refresh++ }.padding(vertical=12.dp), contentAlignment=Alignment.Center) {
                                Text(label, fontWeight=FontWeight.SemiBold, color=if(tab==i) White else Muted)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    if (history.isEmpty()) {
                        Box(Modifier.fillMaxWidth().weight(1f), contentAlignment=Alignment.Center) {
                            Column(horizontalAlignment=Alignment.CenterHorizontally) {
                                Icon(if(tab==0) Icons.Default.Downloading else Icons.Default.History, null, tint=Blue, modifier=Modifier.size(42.dp))
                                Spacer(Modifier.height(10.dp))
                                Text(if(tab==0) "Nenhum download ainda" else "Seu histórico aparecerá aqui", color=Muted)
                                Text("Os itens salvos ficam neste aparelho", color=Muted, fontSize=11.sp)
                            }
                        }
                    } else {
                        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement=Arrangement.spacedBy(9.dp)) {
                            history.sortedByDescending { it.time }.forEach { item ->
                                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).padding(12.dp), verticalAlignment=Alignment.CenterVertically) {
                                    Box(Modifier.size(54.dp).background(Brush.linearGradient(listOf(Blue, Red)), RoundedCornerShape(12.dp)), contentAlignment=Alignment.Center) {
                                        Icon(if(item.format=="MP3") Icons.Default.MusicNote else Icons.Default.PlayArrow, null, tint=White, modifier=Modifier.size(29.dp))
                                    }
                                    Spacer(Modifier.width(11.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(item.title, fontWeight=FontWeight.SemiBold, maxLines=1, overflow=TextOverflow.Ellipsis)
                                        Text("${item.format} • ${item.quality}", color=Orange, fontSize=11.sp)
                                        Text(item.url, color=Muted, fontSize=10.sp, maxLines=1, overflow=TextOverflow.Ellipsis)
                                    }
                                    IconButton(onClick={url=item.url; showOptions=true}) { Icon(Icons.Default.Refresh, "Usar link novamente", tint=Blue) }
                                }
                            }
                        }
                    }
                }
                Row(Modifier.fillMaxWidth().background(Color(0xFF091426)).padding(vertical=12.dp), horizontalArrangement=Arrangement.Center, verticalAlignment=Alignment.CenterVertically) {
                    Icon(Icons.Default.Shield, null, tint=Orange, modifier=Modifier.size(14.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Downloads de mídia autorizada • Sem anúncios", color=Muted, fontSize=10.sp)
                }
            }
            if (showOptions) {
                AlertDialog(
                    onDismissRequest={showOptions=false},
                    containerColor=Panel,
                    title={ Text("Escolha seu download", fontWeight=FontWeight.Bold) },
                    text={
                        Column {
                            Text("Deslize entre os formatos", color=Muted, fontSize=12.sp)
                            Spacer(Modifier.height(12.dp))
                            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                                listOf("MP3", "MP4").forEachIndexed { i, fmt ->
                                    Column(Modifier.width(132.dp).background(if(selectedFormat==i) Blue.copy(alpha=.28f) else Navy, RoundedCornerShape(16.dp))
                                        .clickable { selectedFormat=i }.padding(14.dp)) {
                                        Icon(if(i==0) Icons.Default.MusicNote else Icons.Default.Movie, null, tint=if(selectedFormat==i) Orange else Muted, modifier=Modifier.size(27.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text(fmt, fontWeight=FontWeight.Black, fontSize=19.sp)
                                        Text(if(i==0) "Áudio" else "Vídeo HD", color=Muted, fontSize=12.sp)
                                        if(selectedFormat==i) Text("✓ Selecionado", color=Orange, fontSize=10.sp)
                                    }
                                }
                            }
                            Spacer(Modifier.height(16.dp))
                            if(selectedFormat==1) {
                                Text("QUALIDADE DO VÍDEO", color=Muted, fontSize=11.sp, fontWeight=FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                    listOf("720p","1080p").forEach { q ->
                                        FilterChip(selected=quality==q, onClick={quality=q}, label={Text(q)}, colors=FilterChipDefaults.filterChipColors(selectedContainerColor=Red, selectedLabelColor=White))
                                    }
                                }
                            } else {
                                Text("MP3 • Qualidade padrão", color=Orange, fontWeight=FontWeight.SemiBold)
                                Text("A conversão de páginas sociais não está habilitada nesta versão inicial.", color=Muted, fontSize=12.sp)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text("Links de páginas sociais podem não ser baixáveis diretamente. Esta versão baixa URLs diretas de arquivos de mídia.", color=Muted, fontSize=11.sp)
                        }
                    },
                    confirmButton={
                        Button(onClick={
                            val fmt=if(selectedFormat==0) "MP3" else "MP4"
                            val q=if(selectedFormat==0) "Padrão" else quality
                            val title=Uri.parse(url).host?.removePrefix("www.") ?: "Mídia salva"
                            val item=HistoryItem(url, title, fmt, q, System.currentTimeMillis())
                            history=(listOf(item)+history.filterNot { it.url==url && it.format==fmt }).take(100)
                            saveHistory(prefs, history)
                            showOptions=false
                            if (isDirectMedia(url)) {
                                try {
                                    val request=DownloadManager.Request(Uri.parse(url))
                                        .setTitle("$title.$fmt")
                                        .setDescription("BlueRush • download de mídia")
                                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "BlueRush_${System.currentTimeMillis()}_${if(fmt=="MP3") "audio" else "video"}.${Uri.parse(url).lastPathSegment?.substringAfterLast('.', "mp4") ?: "mp4"}")
                                    val manager=activity.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                    manager.enqueue(request)
                                    notice="Download enviado ao gerenciador do Android"
                                } catch (_: Exception) { notice="Não foi possível iniciar. Confira o link." }
                            } else {
                                notice="Link salvo no histórico; esta URL não parece ser um arquivo direto."
                                Toast.makeText(activity, "Link salvo. Links de páginas sociais exigem integração compatível.", Toast.LENGTH_LONG).show()
                            }
                        }, colors=ButtonDefaults.buttonColors(containerColor=Red)) { Text("CONTINUAR") }
                    },
                    dismissButton={ TextButton(onClick={showOptions=false}) { Text("Cancelar", color=Muted) } }
                )
            }
        }
    }
}

private fun isDirectMedia(raw: String): Boolean {
    return try {
        val uri=Uri.parse(raw)
        val path=(uri.path ?: "").lowercase()
        uri.scheme in listOf("http","https") && listOf(".mp4",".mp3",".m4a",".webm",".aac",".wav",".mov").any { path.endsWith(it) }
    } catch (_: Exception) { false }
}

private fun loadHistory(prefs: android.content.SharedPreferences): List<HistoryItem> {
    return try {
        val array=JSONArray(prefs.getString("history", "[]"))
        (0 until array.length()).map { i ->
            val o=array.getJSONObject(i)
            HistoryItem(o.getString("url"), o.getString("title"), o.getString("format"), o.getString("quality"), o.getLong("time"))
        }
    } catch (_: Exception) { emptyList() }
}
private fun saveHistory(prefs: android.content.SharedPreferences, items: List<HistoryItem>) {
    val array=JSONArray()
    items.forEach { item ->
        array.put(JSONObject().put("url",item.url).put("title",item.title).put("format",item.format).put("quality",item.quality).put("time",item.time))
    }
    prefs.edit().putString("history",array.toString()).apply()
}
