# BlueRush — Android starter project

Projeto inicial nativo Android (Kotlin + Jetpack Compose) para um gerenciador de downloads com:
- campo para colar URL e botão BAIXAR;
- seletor deslizável MP3 / MP4;
- opções de qualidade de vídeo;
- abas Em andamento e Histórico;
- histórico local com link reutilizável e capa quando disponível;
- tema azul, vermelho e laranja, sem logotipo oficial.

## Limitação importante
Este projeto é uma base funcional de interface e gerenciamento. Links de páginas do YouTube, Instagram, TikTok e Facebook não são necessariamente links diretos de mídia e não podem ser baixados simplesmente com Android DownloadManager. A extração de mídia varia por plataforma e pode ser restringida pelos termos, direitos autorais, autenticação e proteções técnicas. A implementação atual aceita URLs diretas de arquivos de mídia (por exemplo, um URL autorizado que termina em .mp4, .mp3, .m4a, .webm); URLs de páginas sociais são guardadas no histórico e exibem uma mensagem explicando a limitação, em vez de fingir que o download funcionou.

MP3: o projeto não realiza conversão de vídeo para MP3 ainda. Isso requer um componente de conversão apropriado e tratamento dos direitos/permissões da mídia.

## Como abrir
1. Instale Android Studio recente.
2. Abra esta pasta como projeto.
3. Aguarde a sincronização do Gradle.
4. Conecte o Xiaomi 14T com depuração USB ativada ou use um emulador e pressione Run.

Foi criado como starter project; não é um APK pronto. O ambiente onde estes arquivos foram montados não tem uma toolchain Android confirmada para compilar e testar o APK.

## Permissões
A aplicação usa `DownloadManager` para baixar URLs diretas. Downloads são gerenciados pelo Android. Não pede acesso amplo a todos os arquivos.
